module.exports = {
    HOST: "remotemysql.com",
    USER: "j6zQXIyB22",
    PASSWORD: "r8E4xAwtmU",
    DB: "j6zQXIyB22",
    PORT: "3306",
    dialect: "mysql",
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  };