# Lynx task for Product and Currency convert for the product price :

## Using node.js 

# packages using :
- Express.js
- Axios
- Sequelize
- Mysql2

# How to run this app
- Extract the app into folder
- Go to the folder via terminal
- Hit the npm i
- And node server

# Note :
- Any concern or issue while running an app, Please let me know