module.exports = (sequelize, Sequelize) => {
    const Product = sequelize.define("product", {
      name: {
        type: Sequelize.STRING
      },
      price:{
        type:Sequelize.INTEGER
      },
      description: {
        type: Sequelize.STRING
      },
      productViewed: {
        type: Sequelize.INTEGER
      },
      isDeleted: {
        type: Sequelize.BOOLEAN
      },
      createdDate: {
        type: Sequelize.DATE
      },
      updatedDate: {
        type: Sequelize.DATE
      },
      deletedDate: {
        type: Sequelize.DATE
      }
    });
    return Product;
  };