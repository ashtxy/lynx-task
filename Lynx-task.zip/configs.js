module.exports = {
    portNo: 7000,
    currAPICon: "https://api.apilayer.com/currency_data/convert",
    apiKey: "gX1uy4uGpdLXw6mGUJk4oSWPfjMh5vyz"
}