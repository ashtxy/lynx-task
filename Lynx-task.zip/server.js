const express = require("express");
const prodApp = express();
prodApp.use(express.json());
const {portNo} = require("./configs");
const prodDB = require("./models");
const theRouter = require("./routes");

prodDB.sequelize.sync({ force: false }).then(() => {
    console.log("ReSynced.");
});
prodApp.use("/", theRouter);

prodApp.listen(portNo, () => {
    console.log(`Server is running on port ${portNo}.`);
});