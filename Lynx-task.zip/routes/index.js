const express = require("express");
const axios = require("axios");
var theRoutes = express.Router();
// Doing the functionality for processing the API here only :
const theDB = require("../models");
const CurrService = require("../currencyService");

theRoutes.get("/single-prod", async (req, res) => {
    try {
        const {prodId, cur} = req.query;
        const [getSingleProd, row] = await theDB.sequelize.query(`SELECT * FROM product where id=${prodId}`);
        if(row && row.length){
            // update the view count:
            await theDB.sequelize.query(`UPDATE product SET productViewed = productViewed + 1 WHERE id =${prodId}`)
            await Promise.all(getSingleProd && getSingleProd.map(async(vals) => {
                return vals.price = await CurrService.currencyPriceConvert(vals.price, cur );
            }))
            return res.status(500).send({
                message: "Fetched successfully",
                data: getSingleProd
            });
        }
        return res.status(500).send({
            message: "Failed to Fetch",
            data: {}
        });
    } catch (error) {
        console.log(error);
        return res.status(200).send({
            message: "Error while fetching"
        });
    }
});

theRoutes.get("/most-viewed-prod", async (req, res) => {
    try {
        const limitVal = req.query && req.query.limit ? parseInt(req.query.limit) : 5;
        const cur = req.query && req.query.cur ? req.query.cur : "USD";
        const [mostViewedProd, row] = await theDB.sequelize.query(`SELECT * FROM product ORDER BY productViewed DESC LIMIT ${limitVal}`);
        if(mostViewedProd && mostViewedProd.length){
            await Promise.all(mostViewedProd && mostViewedProd.map(async(vals) => {
                return vals.price = await CurrService.currencyPriceConvert(vals.price, cur );
            }));
            return res.status(200).send({
                message: "Fetched successfully",
                data: mostViewedProd
            });
        }
        return res.status(500).send({
            message: "Failed to Fetch",
            data: {}
        });
    } catch (error) {
        console.log(error);
        return res.status(500).send({
            message: "Error while fetching"
        });
    }
});

module.exports = theRoutes;

