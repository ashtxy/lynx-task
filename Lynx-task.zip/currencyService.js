const axios = require("axios");
const {currAPICon, apiKey} = require("./configs");

async function currencyPriceConvert(price, currency){
    if(price){
        const formatAPiUrl = `${currAPICon}?to=USD&from=${currency || "EUR"}&amount=${price}`;
        const resultCurr = await axios.get(formatAPiUrl, {
            headers: {
                "apikey": apiKey
            }
        });
        return resultCurr.data ? resultCurr.data.result : price;
    }
    return price;
}
module.exports = {
    currencyPriceConvert
}
